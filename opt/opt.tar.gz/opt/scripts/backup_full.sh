#!/bin/bash

ORIGEN=$1
DESTINO=$2
if [ "$1"  =  "-help" ]; then 
	echo "Uso: backup_full.sh origen destino"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir "
	exit 0 
fi
 
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el destino no existe "
	exit 1
fi


FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)
ARCHIVO=${NOMBRE}_bkp_${FECHA}.tar.gz

tar -czf $DESTINO/$ARCHIVO $ORIGEN
echo "Backup completado: $ARCHIVO"
