history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
ls_realse -a
lsb_release -a
apt update
apt upgrade
apt autoremove
ping -c 3 8.8.8.8
nano /etc/resolv.conf
cat /etc/debian_version
/etc/apt/sources.list
vi /etc/apt/source.list
vi /etc/apr/source.list
hostname
/etc/apt/source.list
vi /etc/apt/source.list
vi /etc/apt/source.list
ls -ls /etc/apt/
/etc/apt/sources.list
ls -la /etc/apt/
rm /etc/apt/source.list.swp
rm /etc/apt/.source.list.swp
ls -la /etc/apt/
vim /etc/apt/sources.list
apt update
apt full-upgrade
reboot 
ip a
ls -la /root/
apt install apache2
apt show apache2
ls /root/
tar xvzf Material_Adicional_TPVMCA.tar.gz
cp /root/index.php /var/wwww/html/
cp /root/index.php/ /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
apt update
apt install php libapache2-mod-php
apt install mariadb-server -y
/Material_Adicional_TPVMCA# mysql -u root < db.sql
cd /root/Material_Adicional_TPVMCA
mysql -u root < db.sql
mysql -u root
ip a
tail -n 20 /var/log/apache2/error.log
apt install php-mysqli -y
systemctl restart apache2
ip route 
vi /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
ip a
shutdown -h now
